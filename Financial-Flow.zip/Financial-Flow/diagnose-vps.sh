#!/bin/bash

# VPS Deployment Diagnostic Script
# Run this script on your VPS to diagnose deployment issues

echo "======================================"
echo "Personal Finance Tracker VPS Diagnostics"
echo "======================================"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Get server IP
SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || curl -s ipinfo.io/ip 2>/dev/null || echo "Unknown")

echo "Server IP: $SERVER_IP"
echo "Timestamp: $(date)"
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    print_error "Not in application directory. Please cd to /var/www/personal-finance-tracker"
    exit 1
fi

# 1. Check Application Status
echo "=== 1. APPLICATION STATUS ==="
if command -v pm2 >/dev/null 2>&1; then
    pm2 list
    PM2_STATUS=$(pm2 list | grep "personal-finance-tracker" | awk '{print $10}')
    if [ "$PM2_STATUS" = "online" ]; then
        print_status "Application is running via PM2"
    else
        print_error "Application is not running via PM2"
    fi
else
    print_error "PM2 is not installed"
fi
echo ""

# 2. Check Port Usage
echo "=== 2. PORT USAGE ==="
if command -v ss >/dev/null 2>&1; then
    ss -tlnp | grep -E ":(80|443|3001|3002|5000)"
    if ss -tlnp | grep -q ":3001"; then
        print_status "Port 3001 is in use"
    elif ss -tlnp | grep -q ":3002"; then
        print_status "Port 3002 is in use"
    else
        print_error "Neither port 3001 nor 3002 is in use"
    fi
else
    print_warning "ss command not available"
fi
echo ""

# 3. Check Nginx Status
echo "=== 3. NGINX STATUS ==="
if command -v nginx >/dev/null 2>&1; then
    sudo systemctl status nginx --no-pager -l | head -10
    if systemctl is-active --quiet nginx; then
        print_status "Nginx is running"
    else
        print_error "Nginx is not running"
    fi
    
    # Check nginx configuration
    if sudo nginx -t 2>/dev/null; then
        print_status "Nginx configuration is valid"
    else
        print_error "Nginx configuration has errors"
        sudo nginx -t
    fi
else
    print_error "Nginx is not installed"
fi
echo ""

# 4. Check Database Status
echo "=== 4. DATABASE STATUS ==="
if command -v psql >/dev/null 2>&1; then
    sudo systemctl status postgresql --no-pager -l | head -10
    if systemctl is-active --quiet postgresql; then
        print_status "PostgreSQL is running"
        
        # Check if database exists
        if [ -f ".env" ]; then
            source .env
            if PGPASSWORD="$PGPASSWORD" psql -h localhost -U "$PGUSER" -d "$PGDATABASE" -c "SELECT 1;" >/dev/null 2>&1; then
                print_status "Database connection successful"
            else
                print_error "Database connection failed"
            fi
        else
            print_warning ".env file not found"
        fi
    else
        print_error "PostgreSQL is not running"
    fi
else
    print_error "PostgreSQL is not installed"
fi
echo ""

# 5. Check Application Logs
echo "=== 5. APPLICATION LOGS (Last 10 lines) ==="
if command -v pm2 >/dev/null 2>&1; then
    pm2 logs personal-finance-tracker --lines 10 2>/dev/null || print_warning "No PM2 logs available"
else
    print_warning "PM2 not available for logs"
fi
echo ""

# 6. Check Environment Configuration
echo "=== 6. ENVIRONMENT CONFIGURATION ==="
if [ -f ".env" ]; then
    print_status ".env file exists"
    source .env
    echo "NODE_ENV: $NODE_ENV"
    echo "PORT: $PORT"
    echo "Database configured: $([ -n "$DATABASE_URL" ] && echo "Yes" || echo "No")"
else
    print_error ".env file not found"
fi
echo ""

# 7. Check Build Status
echo "=== 7. BUILD STATUS ==="
if [ -f "dist/index.js" ]; then
    print_status "Application is built (dist/index.js exists)"
    BUILD_SIZE=$(du -h dist/index.js | cut -f1)
    echo "Build size: $BUILD_SIZE"
else
    print_error "Application is not built (dist/index.js missing)"
fi
echo ""

# 8. Check Firewall Status
echo "=== 8. FIREWALL STATUS ==="
if command -v ufw >/dev/null 2>&1; then
    sudo ufw status
    if sudo ufw status | grep -q "Status: active"; then
        print_status "UFW firewall is active"
        if sudo ufw status | grep -q "80/tcp"; then
            print_status "Port 80 is allowed"
        else
            print_error "Port 80 is not allowed"
        fi
    else
        print_warning "UFW firewall is not active"
    fi
else
    print_warning "UFW is not installed"
fi
echo ""

# 9. Test Local Connectivity
echo "=== 9. LOCAL CONNECTIVITY TEST ==="
if [ -f ".env" ]; then
    source .env
    APP_PORT=${PORT:-3001}
    
    if curl -s -f http://localhost:$APP_PORT >/dev/null 2>&1; then
        print_status "Application responds on localhost:$APP_PORT"
    else
        print_error "Application does not respond on localhost:$APP_PORT"
    fi
    
    # Test through nginx
    if curl -s -f http://localhost:80 >/dev/null 2>&1; then
        print_status "Nginx responds on port 80"
    else
        print_error "Nginx does not respond on port 80"
    fi
else
    print_warning "Cannot determine application port"
fi
echo ""

# 10. IP ACCESS CHECK
echo "=== 10. IP ACCESS CONFIGURATION ==="
print_status "Server IP: $SERVER_IP"
print_status "Access your app at: http://$SERVER_IP"
echo "No domain configuration needed - using IP access only"
echo ""

# 11. Generate Fix Commands
echo "=== 11. RECOMMENDED FIXES ==="
echo "Based on the diagnostics above, try these commands:"
echo ""

# Check PM2 status and suggest fixes
if ! command -v pm2 >/dev/null 2>&1 || ! pm2 list | grep -q "personal-finance-tracker.*online"; then
    echo "Application not running:"
    echo "  ./deploy.sh fix"
    echo ""
fi

# Check nginx status
if ! systemctl is-active --quiet nginx; then
    echo "Nginx not running:"
    echo "  sudo systemctl start nginx"
    echo "  sudo systemctl enable nginx"
    echo ""
fi

# Check database
if ! systemctl is-active --quiet postgresql; then
    echo "PostgreSQL not running:"
    echo "  sudo systemctl start postgresql"
    echo "  sudo systemctl enable postgresql"
    echo ""
fi

# IP-only deployment - no DNS needed
echo "IP-only deployment:"
echo "  Access your app at: http://$SERVER_IP"
echo ""

# Check firewall
if ! sudo ufw status | grep -q "80/tcp"; then
    echo "Firewall blocking HTTP:"
    echo "  sudo ufw allow 80/tcp"
    echo "  sudo ufw allow 443/tcp"
    echo ""
fi

echo "=== DIAGNOSTIC COMPLETE ==="
echo "Your server IP: $SERVER_IP"
echo "Access via IP: http://$SERVER_IP"
echo "No domain needed - IP-only deployment"
echo ""
echo "If DNS is correct and services are running, try:"
echo "  ./deploy.sh fix"
echo ""