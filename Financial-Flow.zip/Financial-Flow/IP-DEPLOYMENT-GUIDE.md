# VPS IP-Only Deployment Guide

## Quick Deployment Steps

1. **Upload your project files to VPS**:
   ```bash
   # From your local machine
   scp -r * user@your-vps-ip:/home/user/personal-finance-tracker/
   ```

2. **SSH into your VPS**:
   ```bash
   ssh user@your-vps-ip
   cd personal-finance-tracker
   ```

3. **Run the deployment script**:
   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```

4. **Get your server IP**:
   ```bash
   curl ifconfig.me
   ```

5. **Access your app**:
   ```
   http://YOUR_SERVER_IP
   ```

## If Deployment Shows "Success" but App Not Accessible

Run the diagnostic script:
```bash
./diagnose-vps.sh
```

Then run the fix command:
```bash
./deploy.sh fix
```

## Common Issues and Solutions

### 1. Application Not Running
```bash
./deploy.sh status
./deploy.sh restart
```

### 2. Port Issues
```bash
./deploy.sh fix
```

### 3. Firewall Blocking Access
```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
```

### 4. Check Application Logs
```bash
./deploy.sh logs
```

## Manual Verification

1. **Check if app is running**:
   ```bash
   pm2 list
   ```

2. **Test local access**:
   ```bash
   curl http://localhost:3001
   ```

3. **Test external access**:
   ```bash
   curl http://YOUR_SERVER_IP
   ```

## Management Commands

- `./deploy.sh status` - Check all services
- `./deploy.sh logs` - View application logs
- `./deploy.sh restart` - Restart application
- `./deploy.sh fix` - Fix any issues
- `./deploy.sh update` - Update application
- `./deploy.sh backup` - Backup database

## Expected Result

After successful deployment:
- Application runs on port 3001 internally
- Nginx forwards traffic from port 80 to 3001
- Access via `http://YOUR_SERVER_IP`
- PM2 manages the application process
- PostgreSQL database is configured and running

## Troubleshooting

If the app still doesn't work after deployment:

1. **Run diagnostics**:
   ```bash
   ./diagnose-vps.sh
   ```

2. **Check specific services**:
   ```bash
   sudo systemctl status nginx
   sudo systemctl status postgresql
   pm2 status
   ```

3. **View logs**:
   ```bash
   ./deploy.sh logs
   sudo journalctl -u nginx -f
   ```

The diagnostic script will show you exactly what's wrong and provide specific fix commands.