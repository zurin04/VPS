# VPS Deployment Troubleshooting Guide

## Common Issues and Solutions

### 1. Application Shows "Success" but Not Accessible

**Most Common Causes:**
- DNS not pointing to server IP
- Firewall blocking ports
- Application not running on correct port
- Nginx configuration issues

**Quick Diagnostics:**
```bash
# Run these commands on your VPS:
./deploy.sh status
./deploy.sh logs
sudo systemctl status nginx
sudo ufw status
```

### 2. Port Configuration Issues

The deployment script uses port 3001/3002 but your Replit version uses port 5000. This mismatch can cause issues.

**Fix:**
```bash
# On your VPS, run:
./deploy.sh fix
```

### 3. DNS and Domain Setup

**Check if DNS is properly configured:**
```bash
# From your local machine:
nslookup zaihash.xyz
ping zaihash.xyz
```

**If DNS is not configured:**
1. Go to your domain registrar (GoDaddy, Namecheap, etc.)
2. Add an A record pointing `zaihash.xyz` to your VPS IP address
3. Wait 15-30 minutes for DNS propagation

### 4. Nginx Configuration

**Check Nginx status:**
```bash
sudo nginx -t
sudo systemctl status nginx
sudo journalctl -u nginx -f
```

### 5. Application Logs

**View application logs:**
```bash
./deploy.sh logs
pm2 logs personal-finance-tracker
```

### 6. Database Issues

**Check database connection:**
```bash
sudo -u postgres psql -c "\l"
```

## Quick Fix Command

Run this comprehensive fix command on your VPS:
```bash
./deploy.sh fix
```

This will:
- Stop and restart the application
- Check and fix port configuration
- Reset database if needed
- Verify all services are running

## Manual Verification Steps

1. **Check if application is running:**
   ```bash
   pm2 list
   curl http://localhost:3001
   ```

2. **Check if Nginx is forwarding correctly:**
   ```bash
   curl -I http://your-domain.com
   ```

3. **Check firewall:**
   ```bash
   sudo ufw status
   ```

4. **Check DNS:**
   ```bash
   dig finance.zaihash.xyz
   ```

## If Still Not Working

1. **Check your VPS IP address:**
   ```bash
   curl ifconfig.me
   ```

2. **Make sure DNS A record points to this IP**

3. **Try accessing via IP directly:**
   ```bash
   http://YOUR_VPS_IP
   ```

4. **Check if port 80 is open:**
   ```bash
   sudo netstat -tlnp | grep :80
   ```

## Contact Information

If you continue having issues, provide:
1. Your VPS IP address
2. Domain name
3. Output of `./deploy.sh status`
4. Output of `./deploy.sh logs`