#!/bin/bash

# Personal Finance Tracker - Simple VPS Deployment
# One script for deployment and management

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Configuration
APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"
DB_NAME="personal_finance_db"
DB_USER="finance_user"

# Management commands
if [ "$1" = "status" ]; then
    pm2 status
    ss -tlnp | grep -E ":(80|3001)" || echo "No ports in use"
    exit 0
elif [ "$1" = "logs" ]; then
    pm2 logs $APP_NAME --lines 50
    exit 0
elif [ "$1" = "restart" ]; then
    cd $APP_DIR && pm2 restart $APP_NAME
    exit 0
elif [ "$1" = "fix" ]; then
    cd $APP_DIR
    pm2 delete $APP_NAME 2>/dev/null || true
    
    # Get or generate password
    if [ -f ".env" ]; then
        source .env
        DB_PASSWORD=${PGPASSWORD:-$(openssl rand -base64 32)}
    else
        DB_PASSWORD=$(openssl rand -base64 32)
    fi
    
    # Create environment
    cat > .env << EOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME
SESSION_SECRET=finance-secret-$(date +%s)
NODE_ENV=production
PORT=3001
PGHOST=localhost
PGPORT=5432
PGUSER=$DB_USER
PGPASSWORD=$DB_PASSWORD
PGDATABASE=$DB_NAME
EOF
    
    # Build if needed
    [ ! -f "dist/index.js" ] && npm run build
    
    # Restart
    pm2 start ecosystem.config.cjs
    pm2 save
    print_status "Application fixed and restarted"
    curl -s http://localhost:3001 >/dev/null && print_status "Working on port 3001" || print_error "Still not working"
    exit 0
fi

# Main deployment
print_status "Starting deployment..."

# Check prerequisites
[[ $EUID -eq 0 ]] && { print_error "Don't run as root"; exit 1; }

# Install system dependencies
print_status "Installing dependencies..."
sudo apt update -y
sudo apt install -y curl wget nodejs npm postgresql postgresql-contrib nginx

# Install PM2
sudo npm install -g pm2

# Start services
sudo systemctl enable --now postgresql nginx

# Setup application directory
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR
cp -r . $APP_DIR/
cd $APP_DIR

# Generate credentials
DB_PASSWORD=$(openssl rand -base64 32)

# Setup database
print_status "Setting up database..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;
CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE $DB_NAME OWNER $DB_USER;
\q
EOF

# Create environment
cat > .env << EOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME
SESSION_SECRET=finance-secret-$(date +%s)
NODE_ENV=production
PORT=3001
PGHOST=localhost
PGPORT=5432
PGUSER=$DB_USER
PGPASSWORD=$DB_PASSWORD
PGDATABASE=$DB_NAME
EOF

# Install and build
print_status "Building application..."
npm install
npm run db:push
npm run build

# Create PM2 config
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: '$APP_NAME',
    script: 'node',
    args: 'dist/index.js',
    cwd: '$APP_DIR',
    env_file: '.env',
    instances: 1,
    autorestart: true
  }]
};
EOF

# Configure Nginx
print_status "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/$APP_NAME > /dev/null << EOF
server {
    listen 80 default_server;
    server_name _;
    location / {
        proxy_pass http://localhost:3001;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application..."
pm2 start ecosystem.config.cjs
pm2 save

# Setup firewall
sudo ufw --force enable
sudo ufw allow 22,80/tcp

# Get server IP
SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || echo "Unknown")

echo ""
echo "================================"
print_status "DEPLOYMENT COMPLETE!"
echo "================================"
echo ""
echo "Access your app at: http://$SERVER_IP"
echo ""
echo "Management commands:"
echo "  ./deploy-simple.sh status   - Check status"
echo "  ./deploy-simple.sh logs     - View logs"
echo "  ./deploy-simple.sh restart  - Restart app"
echo "  ./deploy-simple.sh fix      - Fix issues"
echo ""