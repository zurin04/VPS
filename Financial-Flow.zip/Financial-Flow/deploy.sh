#!/bin/bash

# Personal Finance Tracker - Production VPS Deployment
# Optimized one-click deployment for Ubuntu VPS - zaihash.xyz

set -e

echo "======================================"
echo "Personal Finance Tracker Deployment"
echo "Domain: $DOMAIN"
echo "======================================"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check prerequisites
[[ $EUID -eq 0 ]] && { print_error "Do not run as root. Use a regular user with sudo privileges."; exit 1; }
command -v sudo >/dev/null || { print_error "sudo is required but not installed."; exit 1; }

# Configuration - IP-only deployment (no domain needed)
DOMAIN="${1:-_}"  # Use _ for IP-only access
APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"
DB_NAME="personal_finance_db"
DB_USER="finance_user"

# Check if running as management command
if [ "$1" = "status" ] || [ "$1" = "logs" ] || [ "$1" = "restart" ] || [ "$1" = "fix" ] || [ "$1" = "ssl" ] || [ "$1" = "backup" ] || [ "$1" = "update" ]; then
    case "$1" in
        status)
            echo "=== APPLICATION STATUS ==="
            pm2 status
            echo ""
            echo "=== NGINX STATUS ==="
            sudo systemctl status nginx --no-pager -l | head -20
            echo ""
            echo "=== DATABASE STATUS ==="
            sudo systemctl status postgresql --no-pager -l | head -20
            echo ""
            echo "=== PORT USAGE ==="
            ss -tlnp | grep -E ":(80|443|3001|3002|5432)" || echo "No conflicts detected"
            ;;
        logs)
            echo "=== APPLICATION LOGS ==="
            pm2 logs $APP_NAME --lines 20
            ;;
        restart)
            cd $APP_DIR
            pm2 restart $APP_NAME
            ;;
        fix)
            echo "=== COMPREHENSIVE APPLICATION FIX ==="
            cd $APP_DIR
            
            # Show current error logs
            echo "=== Current Error Logs ==="
            pm2 logs $APP_NAME --lines 10 2>/dev/null || echo "No logs available"
            echo ""
            
            # Stop all processes
            print_status "Stopping all processes..."
            pm2 delete $APP_NAME 2>/dev/null || true
            pkill -f "node.*dist" 2>/dev/null || true
            
            # Load database password from existing env or generate new
            if [ -f ".env" ]; then
                source .env
                DB_PASSWORD=${PGPASSWORD:-$(openssl rand -base64 32)}
            else
                DB_PASSWORD=$(openssl rand -base64 32)
            fi
            
            # Create fresh environment file with correct port
            print_status "Creating environment file with PORT=3001..."
            cat > .env << EOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME
SESSION_SECRET=finance-secret-$(date +%s)
NODE_ENV=production
PORT=3001
PGHOST=localhost
PGPORT=5432
PGUSER=$DB_USER
PGPASSWORD=$DB_PASSWORD
PGDATABASE=$DB_NAME
EOF
            
            # Clean rebuild
            print_status "Rebuilding application with correct port..."
            rm -rf node_modules dist .next 2>/dev/null || true
            npm install
            print_status "Building application..."
            export NODE_OPTIONS="--max-old-space-size=2048"
            npm run build
            
            # Verify build succeeded
            if [ ! -f "dist/index.js" ]; then
                print_error "Build failed - checking for TypeScript errors..."
                npm run build
                exit 1
            fi
            print_status "Build completed successfully"
            
            # Reset database if needed
            print_status "Checking database..."
            if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U $DB_USER -d $DB_NAME -c "SELECT 1;" >/dev/null 2>&1; then
                print_status "Resetting database..."
                sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;
CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE $DB_NAME OWNER $DB_USER;
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
\q
EOF
                export DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME"
                npm run db:push
            fi
            
            # Test manual start
            print_status "Testing manual start..."
            source .env
            timeout 10s node dist/index.js &
            sleep 5
            if ss -tlnp | grep -q ":3001"; then
                print_status "Manual start successful - application uses port 3001"
                pkill -f "node dist/index.js"
            else
                print_error "Manual start failed - showing error:"
                timeout 5s node dist/index.js
                exit 1
            fi
            
            # Start with PM2
            print_status "Starting with PM2..."
            pm2 start ecosystem.config.cjs
            pm2 save
            sleep 5
            
            # Verify success
            if pm2 list | grep -q "$APP_NAME.*online"; then
                print_status "Application fixed and running"
                if curl -s http://localhost:3001 >/dev/null 2>&1; then
                    print_status "Web server responding on port 3001"
                    print_status "App is live at http://YOUR_SERVER_IP"
                else
                    print_warning "Web server not responding yet - may need more time"
                fi
            else
                print_error "Application still failing"
                pm2 logs $APP_NAME --lines 5
            fi
            ;;
        ssl)
            print_status "Setting up SSL for $DOMAIN..."
            sudo apt update && sudo apt install -y certbot python3-certbot-nginx
            sudo certbot --nginx -d $DOMAIN
            sudo systemctl reload nginx
            print_status "SSL setup completed"
            ;;
        backup)
            BACKUP_DIR="/var/backups/personal-finance-tracker"
            sudo mkdir -p $BACKUP_DIR
            BACKUP_FILE="$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).sql"
            sudo -u postgres pg_dump $DB_NAME > $BACKUP_FILE
            print_status "Database backed up to $BACKUP_FILE"
            ;;
        update)
            cd $APP_DIR
            print_status "Updating application..."
            pm2 stop $APP_NAME
            npm install
            npm run build
            pm2 start $APP_NAME
            print_status "Application updated"
            ;;
    esac
    exit 0
fi

# Main deployment script starts here
print_status "Starting Personal Finance Tracker deployment..."

# Install system dependencies
print_status "Installing system dependencies..."
sudo apt update -y && sudo apt install -y curl wget gnupg postgresql postgresql-contrib nginx certbot python3-certbot-nginx python3 build-essential net-tools

# Install Node.js 20
if ! command -v node &>/dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Install PM2
sudo npm install -g pm2 2>/dev/null || print_warning "PM2 already installed"

# Start services
sudo systemctl enable --now postgresql nginx

# Setup application
print_status "Setting up application..."
sudo mkdir -p $APP_DIR && sudo chown $USER:$USER $APP_DIR

# Copy application files from current directory to app directory
SOURCE_DIR=$(pwd)
print_status "Copying application files from $SOURCE_DIR..."
cp -r . $APP_DIR/ && cd $APP_DIR

# Remove git directory to avoid conflicts
rm -rf .git 2>/dev/null || true

# Verify essential files exist
if [ ! -f "package.json" ]; then
    print_error "package.json not found! Make sure you're running this script from your project directory."
    print_error "Current directory: $(pwd)"
    print_error "Source directory: $SOURCE_DIR"
    ls -la
    exit 1
fi

print_status "Application files copied successfully"

# Generate secure credentials
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Create database and user
print_status "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;
CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE $DB_NAME OWNER $DB_USER;
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
\q
EOF

# Check for port conflicts
APP_PORT=3001
if ss -tlnp | grep -q ":3001"; then
    APP_PORT=3002
    print_warning "Port 3001 in use, switching to 3002"
fi

# Create environment file
print_status "Creating environment configuration..."
cat > .env << ENV
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=$APP_PORT
PGHOST=localhost
PGPORT=5432
PGUSER=$DB_USER
PGPASSWORD=$DB_PASSWORD
PGDATABASE=$DB_NAME
ENV

# Install dependencies
print_status "Installing dependencies..."
npm install

# Setup database schema
print_status "Initializing database..."

# URL encode the password to handle special characters
if command -v python3 >/dev/null 2>&1; then
    DB_PASSWORD_ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$DB_PASSWORD', safe=''))")
else
    print_warning "Python3 not available, using password as-is (may cause issues with special characters)"
    DB_PASSWORD_ENCODED="$DB_PASSWORD"
fi

export DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD_ENCODED@localhost:5432/$DB_NAME"
export SESSION_SECRET
export NODE_ENV=production

# Test database connection first
print_status "Testing database connection..."
if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U $DB_USER -d $DB_NAME -c "SELECT 1;" >/dev/null 2>&1; then
    print_error "Database connection failed. Check PostgreSQL setup."
    exit 1
fi

print_status "Pushing database schema..."
# Try with encoded URL first, then fallback to direct connection
if ! npm run db:push 2>&1; then
    print_warning "Schema push with encoded URL failed, trying direct connection..."
    export DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME"
    if ! npm run db:push 2>&1; then
        print_error "Database schema push failed with both URL formats."
        exit 1
    fi
fi

# Update .env file with working DATABASE_URL
print_status "Updating environment configuration with working database URL..."
cat > .env << ENV
DATABASE_URL=$DATABASE_URL
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=$APP_PORT
PGHOST=localhost
PGPORT=5432
PGUSER=$DB_USER
PGPASSWORD=$DB_PASSWORD
PGDATABASE=$DB_NAME
ENV

# Build application with extended timeout and memory optimization
print_status "Building application..."
export NODE_OPTIONS="--max-old-space-size=4096"
timeout 600 npm run build || {
    print_warning "Build timed out or failed, trying fallback strategy..."
    # Fallback strategy for resource-constrained VPS
    export NODE_OPTIONS="--max-old-space-size=2048"
    timeout 300 npm run build || {
        print_error "Build failed even with fallback strategy. Check available memory and try building locally."
        exit 1
    }
}

# Configure PM2 and services
print_status "Configuring services..."
sudo mkdir -p /var/log/personal-finance-tracker
sudo chown $USER:$USER /var/log/personal-finance-tracker

# PM2 ecosystem configuration
print_status "Creating PM2 configuration..."
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: '$APP_NAME',
    script: 'node',
    args: 'dist/index.js',
    cwd: '$APP_DIR',
    env_file: '.env',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    min_uptime: '10s',
    max_restarts: 5,
    restart_delay: 5000,
    kill_timeout: 5000,
    error_file: '/var/log/personal-finance-tracker/error.log',
    out_file: '/var/log/personal-finance-tracker/out.log',
    log_file: '/var/log/personal-finance-tracker/combined.log'
  }]
};
EOF

# Configure Nginx for IP access
print_status "Configuring Nginx for IP access..."

sudo tee /etc/nginx/sites-available/$APP_NAME > /dev/null << EOF
server {
    listen 80 default_server;
    server_name _;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
    
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
EOF

# Enable site configuration
sudo ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application with PM2..."
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Verify application is running
print_status "Verifying application startup..."
sleep 5
if pm2 list | grep -q "$APP_NAME.*online"; then
    print_status "Application started successfully!"
else
    print_error "Application failed to start. Check logs with: pm2 logs $APP_NAME"
    exit 1
fi

# Setup security and firewall
print_status "Configuring security..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Final verification
print_status "Verifying deployment..."
if curl -f -s http://localhost:$APP_PORT >/dev/null 2>&1; then
    print_status "Web server responding correctly on port $APP_PORT"
else
    print_warning "Web server test failed - may need time to start"
fi

echo ""
echo "========================================"
echo "DEPLOYMENT COMPLETED SUCCESSFULLY"
echo "========================================"
echo ""
echo "Application Details:"
echo "  URL: http://YOUR_SERVER_IP"
echo "  Port: $APP_PORT"
echo "  Directory: $APP_DIR"
echo "  Database: $DB_NAME"
echo ""
echo "Management Commands:"
echo "  ./deploy.sh status              - Check status"
echo "  ./deploy.sh logs                - View logs"
echo "  ./deploy.sh restart             - Restart app"
echo "  ./deploy.sh fix                 - Fix any issues"
echo "  ./deploy.sh ssl                 - Setup SSL"
echo "  ./deploy.sh update              - Update app"
echo "  ./deploy.sh backup              - Backup data"
echo ""
echo "Next Steps:"
echo "1. Your Personal Finance Tracker is live at: http://YOUR_SERVER_IP"
echo "2. Get your server IP with: curl ifconfig.me"
echo "3. Access your app at: http://[YOUR_SERVER_IP]"
echo ""
echo "Your Personal Finance Tracker is ready!"