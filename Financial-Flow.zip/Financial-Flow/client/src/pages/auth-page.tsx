import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Wallet, Mail, User, ChartLine } from "lucide-react";

declare global {
  interface Window {
    ethereum?: any;
  }
}

export default function AuthPage() {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const signupForm = useForm({
    defaultValues: {
      email: "",
      username: "",
      password: "",
    },
  });

  const loginForm = useForm({
    defaultValues: {
      emailOrUsername: "",
      password: "",
    },
  });

  const signupMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/auth/signup", data),
    onSuccess: (response) => {
      toast({ title: "Account created successfully! Welcome!" });
      queryClient.setQueryData(["/api/auth/user"], response);
      // Invalidate and refetch user data to ensure consistency
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      // Use router navigation instead of window.location
      setTimeout(() => setLocation("/"), 100);
    },
    onError: (error: any) => {
      toast({ 
        title: "Signup failed", 
        description: error.message || "Failed to create account",
        variant: "destructive" 
      });
    },
  });

  const loginMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/auth/login", data),
    onSuccess: (response) => {
      toast({ title: "Welcome back!" });
      queryClient.setQueryData(["/api/auth/user"], response);
      // Invalidate and refetch user data to ensure consistency
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      // Use router navigation instead of window.location
      setTimeout(() => setLocation("/"), 100);
    },
    onError: (error: any) => {
      toast({ 
        title: "Login failed", 
        description: error.message || "Invalid credentials",
        variant: "destructive" 
      });
    },
  });

  const web3LoginMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/auth/web3-login", data),
    onSuccess: (response) => {
      toast({ title: "Web3 login successful!" });
      queryClient.setQueryData(["/api/auth/user"], response);
      // Invalidate and refetch user data to ensure consistency
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      // Use router navigation instead of window.location
      setTimeout(() => setLocation("/"), 100);
    },
    onError: (error: any) => {
      toast({ 
        title: "Web3 login failed", 
        description: error.message || "Failed to authenticate with wallet",
        variant: "destructive" 
      });
    },
  });

  const handleSignup = (data: any) => {
    signupMutation.mutate(data);
  };

  const handleLogin = (data: any) => {
    loginMutation.mutate(data);
  };

  const handleWeb3Login = async () => {
    if (!window.ethereum) {
      toast({
        title: "Web3 Wallet Required",
        description: "Please install MetaMask or another Web3 wallet to continue",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      // Request account access
      const accounts = await window.ethereum.request({ 
        method: 'eth_requestAccounts' 
      });
      
      if (accounts.length === 0) {
        throw new Error('No accounts found');
      }

      const walletAddress = accounts[0];
      
      // In a real implementation, you would request a signature to verify ownership
      // For now, we'll just use the wallet address
      web3LoginMutation.mutate({
        walletAddress,
        signature: "mock_signature" // In production, get actual signature
      });
      
    } catch (error: any) {
      toast({
        title: "Web3 Connection Failed",
        description: error.message || "Failed to connect wallet",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light via-white to-success-light flex items-center justify-center p-4">
      <div className="w-full max-w-4xl grid md:grid-cols-2 gap-8 items-center">
        
        {/* Hero Section */}
        <div className="text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start mb-6">
            <ChartLine className="text-primary text-4xl mr-3" />
            <h1 className="text-4xl font-bold text-gray-900">FinanceTracker</h1>
          </div>
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">
            Take Control of Your Financial Future
          </h2>
          <p className="text-gray-600 mb-6">
            Track your income, expenses, and goals with our comprehensive financial management platform. 
            Create an account with email/username or connect your Web3 wallet.
          </p>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center text-gray-600">
              <Mail className="w-4 h-4 mr-2 text-primary" />
              Email/Username Login
            </div>
            <div className="flex items-center text-gray-600">
              <Wallet className="w-4 h-4 mr-2 text-primary" />
              Web3 Wallet Login
            </div>
            <div className="flex items-center text-gray-600">
              <ChartLine className="w-4 h-4 mr-2 text-primary" />
              Real-time P&L Tracking
            </div>
            <div className="flex items-center text-gray-600">
              <User className="w-4 h-4 mr-2 text-primary" />
              Personal Goals Management
            </div>
          </div>
        </div>

        {/* Auth Forms */}
        <Card className="w-full">
          <CardHeader>
            <CardTitle>Get Started</CardTitle>
            <CardDescription>
              Create an account or sign in to access your dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Sign In</TabsTrigger>
                <TabsTrigger value="signup">Create Account</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login" className="space-y-4">
                <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                  <div>
                    <Label htmlFor="emailOrUsername">Email or Username</Label>
                    <Input
                      id="emailOrUsername"
                      {...loginForm.register("emailOrUsername")}
                      placeholder="Enter your email or username"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      {...loginForm.register("password")}
                      placeholder="Enter your password"
                      required
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Signing in..." : "Sign In"}
                  </Button>
                </form>
                
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-white px-2 text-gray-500">Or continue with</span>
                  </div>
                </div>
                
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={handleWeb3Login}
                  disabled={isLoading || web3LoginMutation.isPending}
                >
                  <Wallet className="w-4 h-4 mr-2" />
                  {isLoading || web3LoginMutation.isPending ? "Connecting..." : "Connect Web3 Wallet"}
                </Button>
              </TabsContent>
              
              <TabsContent value="signup" className="space-y-4">
                <form onSubmit={signupForm.handleSubmit(handleSignup)} className="space-y-4">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      {...signupForm.register("email")}
                      placeholder="Enter your email"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      {...signupForm.register("username")}
                      placeholder="Choose a username"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="signupPassword">Password</Label>
                    <Input
                      id="signupPassword"
                      type="password"
                      {...signupForm.register("password")}
                      placeholder="Create a password"
                      required
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={signupMutation.isPending}
                  >
                    {signupMutation.isPending ? "Creating account..." : "Create Account"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}