import { ChartLine, DollarSign, CheckSquare, Calendar, Target } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-light via-white to-success-light">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <ChartLine className="text-primary text-6xl mr-4" />
            <h1 className="text-5xl font-bold text-gray-900">FinanceTracker</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Take control of your personal finances and productivity with our comprehensive tracking system
          </p>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <DollarSign className="text-success text-4xl mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-4">Income & Expense Tracking</h3>
            <p className="text-gray-600">
              Monitor your daily income and expenses with detailed categorization and P&L calculations
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <CheckSquare className="text-primary text-4xl mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-4">Task Management</h3>
            <p className="text-gray-600">
              Organize your tasks with priorities, deadlines, and progress tracking
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <Calendar className="text-warning text-4xl mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-4">Calendar Overview</h3>
            <p className="text-gray-600">
              View your financial activities and tasks in an interactive calendar format
            </p>
          </div>
        </div>

        {/* Goals Section */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-16">
          <div className="flex items-center justify-center mb-6">
            <Target className="text-primary text-3xl mr-3" />
            <h2 className="text-3xl font-bold text-gray-900">Set and Track Goals</h2>
          </div>
          <p className="text-center text-gray-600 mb-8">
            Define financial goals and monitor your progress with visual indicators and milestone tracking
          </p>
          <div className="text-center">
            <Button 
              onClick={() => window.location.href = '/auth'}
              className="bg-primary hover:bg-primary-dark text-white px-8 py-3 text-lg"
            >
              Get Started - Sign Up
            </Button>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-gray-500">
          <p>Start managing your finances and tasks more effectively today</p>
        </div>
      </div>
    </div>
  );
}