import { useQuery } from "@tanstack/react-query";
import { Plus, Minus, CreditCard } from "lucide-react";
import { format } from "date-fns";
import { useCurrency } from "@/hooks/useCurrency";

export default function RecentTransactions() {
  const { formatCurrency } = useCurrency();
  const { data: income } = useQuery({
    queryKey: ["/api/income"],
    queryFn: () => fetch("/api/income").then(res => res.json()),
  });

  const { data: expenses } = useQuery({
    queryKey: ["/api/expenses"],
    queryFn: () => fetch("/api/expenses").then(res => res.json()),
  });

  const { data: bills } = useQuery({
    queryKey: ["/api/bills"],
    queryFn: () => fetch("/api/bills").then(res => res.json()),
  });

  // Combine and sort all transactions
  const allTransactions = [
    ...(income || []).map((item: any) => ({ ...item, type: "income" })),
    ...(expenses || []).map((item: any) => ({ ...item, type: "expense" })),
    ...(bills || []).map((item: any) => ({ ...item, type: "bill", date: item.dueDate })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 3);

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "income":
        return <Plus className="text-success" />;
      case "expense":
        return <Minus className="text-error" />;
      case "bill":
        return <CreditCard className="text-primary" />;
      default:
        return <CreditCard className="text-gray-600" />;
    }
  };

  const getTransactionBgColor = (type: string) => {
    switch (type) {
      case "income":
        return "bg-success-light";
      case "expense":
        return "bg-error-light";
      case "bill":
        return "bg-primary-light";
      default:
        return "bg-gray-100";
    }
  };

  const getTransactionAmount = (transaction: any) => {
    const amount = parseFloat(transaction.amount);
    switch (transaction.type) {
      case "income":
        return `+${formatCurrency(amount)}`;
      case "expense":
        return `-${formatCurrency(amount)}`;
      case "bill":
        return transaction.status === "paid" ? `-${formatCurrency(amount)}` : formatCurrency(amount);
      default:
        return formatCurrency(amount);
    }
  };

  const getTransactionAmountColor = (transaction: any) => {
    switch (transaction.type) {
      case "income":
        return "text-success";
      case "expense":
        return "text-error";
      case "bill":
        return transaction.status === "paid" ? "text-error" : "text-warning";
      default:
        return "text-gray-900";
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 sm:p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Recent Transactions</h2>
          <button className="text-sm text-primary hover:text-primary-dark font-medium">
            View All
          </button>
        </div>
      </div>
      <div className="divide-y divide-gray-200">
        {allTransactions.length > 0 ? (
          allTransactions.map((transaction: any, index: number) => (
            <div key={index} className="p-4 sm:p-6 flex items-center justify-between">
              <div className="flex items-center space-x-3 min-w-0 flex-1">
                <div className={`w-8 h-8 sm:w-10 sm:h-10 ${getTransactionBgColor(transaction.type)} rounded-lg flex items-center justify-center flex-shrink-0`}>
                  {getTransactionIcon(transaction.type)}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{transaction.description}</p>
                  <p className="text-xs text-gray-500">
                    {transaction.category} • {transaction.type === "bill" ? "Bill" : transaction.type}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className={`text-sm font-semibold ${getTransactionAmountColor(transaction)}`}>
                  {getTransactionAmount(transaction)}
                </p>
                <p className="text-xs text-gray-500">
                  {transaction.type === "bill" && transaction.status === "unpaid" 
                    ? `Due ${format(new Date(transaction.date), "MMM d, yyyy")}`
                    : format(new Date(transaction.date), "MMM d, yyyy")
                  }
                </p>
              </div>
            </div>
          ))
        ) : (
          <div className="p-6 text-center text-gray-500">
            No transactions yet
          </div>
        )}
      </div>
    </div>
  );
}
