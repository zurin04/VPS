import { useQuery } from "@tanstack/react-query";
import { TrendingUp, DollarSign, CreditCard, CheckSquare } from "lucide-react";
import { format } from "date-fns";
import { useCurrency } from "@/hooks/useCurrency";

export default function DashboardOverview() {
  const { formatCurrency } = useCurrency();
  const today = format(new Date(), "yyyy-MM-dd");
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  const { data: dailyPnL } = useQuery({
    queryKey: ["/api/analytics/daily-pnl", { date: today }],
    queryFn: () => fetch(`/api/analytics/daily-pnl?date=${today}`).then(res => res.json()),
  });

  const { data: monthlyStats } = useQuery({
    queryKey: ["/api/analytics/monthly-stats", { year: currentYear, month: currentMonth }],
    queryFn: () => fetch(`/api/analytics/monthly-stats?year=${currentYear}&month=${currentMonth}`).then(res => res.json()),
  });

  const { data: tasks } = useQuery({
    queryKey: ["/api/tasks"],
    queryFn: () => fetch("/api/tasks").then(res => res.json()),
  });

  const pendingTasks = tasks?.filter((task: any) => task.status !== "completed").length || 0;
  const todayTasks = tasks?.filter((task: any) => task.dueDate === today && task.status !== "completed").length || 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8" data-component="dashboard-overview">
      {/* Today's P&L Card */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Today's P&L</p>
            <p className={`text-2xl font-bold ${dailyPnL?.pnl >= 0 ? 'text-success' : 'text-error'}`}>
              {dailyPnL?.pnl >= 0 ? '+' : ''}{formatCurrency(dailyPnL?.pnl || 0)}
            </p>
          </div>
          <div className="w-12 h-12 bg-success-light rounded-lg flex items-center justify-center">
            <TrendingUp className="text-success text-xl" />
          </div>
        </div>
      </div>

      {/* Monthly Income */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Monthly Income</p>
            <p className="text-2xl font-bold text-gray-900">
              {formatCurrency(monthlyStats?.income || 0)}
            </p>
          </div>
          <div className="w-12 h-12 bg-primary-light rounded-lg flex items-center justify-center">
            <DollarSign className="text-primary text-xl" />
          </div>
        </div>
      </div>

      {/* Monthly Expenses */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Monthly Expenses</p>
            <p className="text-2xl font-bold text-gray-900">
              {formatCurrency(monthlyStats?.expenses || 0)}
            </p>
          </div>
          <div className="w-12 h-12 bg-error-light rounded-lg flex items-center justify-center">
            <CreditCard className="text-error text-xl" />
          </div>
        </div>
      </div>

      {/* Pending Tasks */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Pending Tasks</p>
            <p className="text-2xl font-bold text-gray-900">{pendingTasks}</p>
          </div>
          <div className="w-12 h-12 bg-warning-light rounded-lg flex items-center justify-center">
            <CheckSquare className="text-warning text-xl" />
          </div>
        </div>
        <p className="text-xs text-gray-500 mt-2">{todayTasks} due today</p>
      </div>
    </div>
  );
}
